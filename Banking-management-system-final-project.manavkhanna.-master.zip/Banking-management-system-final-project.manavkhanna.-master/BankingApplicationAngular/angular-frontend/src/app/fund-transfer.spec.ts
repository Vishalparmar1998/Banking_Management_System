import { FundTransfer } from './fund-transfer';

describe('FundTransfer', () => {
  it('should create an instance', () => {
    expect(new FundTransfer()).toBeTruthy();
  });
});
