import { FundDeposit } from './fund-deposit';

describe('FundDeposit', () => {
  it('should create an instance', () => {
    expect(new FundDeposit()).toBeTruthy();
  });
});
