import { AccountStatement } from './account-statement';

describe('AccountStatement', () => {
  it('should create an instance', () => {
    expect(new AccountStatement()).toBeTruthy();
  });
});
