export class AccountStatementRequest {
    accountNumber! : number;
}
