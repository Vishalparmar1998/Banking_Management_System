export class FundWithdraw {
    fromAccount! : number;
    amount! : number;
}
