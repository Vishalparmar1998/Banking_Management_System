export class FundDeposit {
    inAccount! : number;
    amount! : number;
}
