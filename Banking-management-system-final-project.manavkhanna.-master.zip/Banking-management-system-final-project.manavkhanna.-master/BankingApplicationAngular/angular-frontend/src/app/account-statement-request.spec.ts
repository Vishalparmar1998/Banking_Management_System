import { AccountStatementRequest } from './account-statement-request';

describe('AccountStatementRequest', () => {
  it('should create an instance', () => {
    expect(new AccountStatementRequest()).toBeTruthy();
  });
});
