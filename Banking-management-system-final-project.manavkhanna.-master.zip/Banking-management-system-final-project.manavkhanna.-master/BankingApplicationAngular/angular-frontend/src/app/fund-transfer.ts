export class FundTransfer {
    fromAccount! : number;
    toAccount! : number;
    amount! : number;
}
