import { FundWithdraw } from './fund-withdraw';

describe('FundWithdraw', () => {
  it('should create an instance', () => {
    expect(new FundWithdraw()).toBeTruthy();
  });
});
